import open3d as o3d
import numpy as np
import matplotlib.pyplot as plt
from sklearn.neighbors import NearestNeighbors
import os
import tkinter as tk
from tkinter import filedialog

def crop_util():
    root = tk.Tk()
    root.withdraw()
    file_path = filedialog.askopenfilename(title="Choosing your point cloud (.pcd, .ply)",
                                           filetypes=[("Point Cloud", "*.pcd *.ply *.xyzn *.xyz")])
    if not file_path:
        print("No chosen file!!!")
        return

    print(f"Reading: {file_path} ...")
    full_pcd = o3d.io.read_point_cloud(file_path)
    print(f"Number of points: {len(full_pcd.points)}")
    # set pointcloud color to red
    colors = np.zeros_like(full_pcd.points)
    colors[:,0] = 1
    full_pcd.colors = o3d.utility.Vector3dVector(colors)

    print("="*50)
    print(
        "1) Press 'Y' twice to align geometry with negative direction of y-axis"
    )
    print("2) Press 'K' to lock screen and to switch to selection mode")
    print("3) Drag for rectangle selection,")
    print("   or use ctrl + left click for polygon selection")
    print("4) Press 'C' to get a selected geometry")
    print("5) Press 'S' to save the selected geometry")
    print("6) Press 'F' to switch to freeview mode")
    print("="*50)
    while True:
        
        o3d.visualization.draw_geometries_with_editing([full_pcd])

        check = input("again? (y/n): ")
        if check.lower() != 'y':
            break
        
if __name__ == "__main__":
    crop_and_analyze()