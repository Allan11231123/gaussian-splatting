import os, sys
import open3d as o3d
import numpy as np
import matplotlib.pyplot as plt
from typing import List
import pcl_curvature
import argparse

def parse_args():
    parser = argparse.ArgumentParser(
        description="Load and visualize a .ply point cloud file."
    )
    parser.add_argument(
        "--dir",
        required=True,
        type=str,
        help="Path to the folder where store the target .ply files."
    )
    parser.add_argument(
        "--file_names",
        required=True,
        nargs="+",
        type=str,
        help="Targeting file names that need to be analyzed."
    )
    parser.add_argument(
        "--radius","-r",
        type=float,
        default=2.0,
        help="Radius to search near points while computing principal components."
    )

    return parser.parse_args()

def load_pointcloud(dir: str, files: List[str]):
    input_pcds = []
    pcd_names = []
    for file in files:
        target_file = os.path.join(dir,file)
        pcd = o3d.io.read_point_cloud(target_file)
        pcd_names.append(file-".ply")
        input_pcds.append(pcd)
    return input_pcds, pcd_names

def compute_principal_component(pcd, radius):
    target_points = np.asarray(pcd.points).astype(np.float64)
    # compute principal component from given point cloud
    result = pcl_curvature.compute(target_points, radius)
    
    # filter out valid pc1/pc2 (avoid NaN value)
    pc1 = result[:,3]
    pc1 = np.nan_to_num(pc1,nan=-1.0)
    pc1_mask = (pc1>0)
    valid_pc1 = np.asarray(pc1)[pc1_mask]
    pc2 = result[:,4]
    pc2 = np.nan_to_num(pc2,nan=-1.0)
    pc2_mask = (pc2>0)
    valid_pc2 = np.asarray(pc2)[pc2_mask]
    
    # compute mean pc1/pc2 and variance
    pc1_mean = valid_pc1.mean()
    pc1_var = valid_pc1.var()
    pc2_mean = valid_pc2.mean()
    pc2_var = valid_pc2.var()
    
    return (pc1_mean, pc2_mean), (pc1_var, pc2_var)
    
def main():
    args = parse_args()
    
    pcd_list, name_list = load_pointcloud(args.dir, args.file_names)
    
    means_list = []
    vars_list = []
    
    for pcd in pcd_list:
        pc_means, pc_vars = compute_principal_component(pcd=pcd, radius=args.radius)
        means_list.append(pc_means)
        vars_list.append(pc_vars)
    
    pc1_means = [pc_means[0] for pc_means in means_list]
    pc2_means = [pc_means[1] for pc_means in means_list]
    x = np.arange(len(name_list))
    width = 0.35
    
    fig, ax = plt.subplot(figsize=(10.6))
    
    rects1 = ax.bar(x-width/2, pc1_means, width, label='mean pc1', capsize=5, color='skyblue', edgecolor='black')
    rects2 = ax.bar(x+width/2, pc2_means, width, label='mean pc2', capsize=5, color='lightcoral', edgecolor='black')
    
    ax.set_ylabel('Eigenvalue Magnitude (Mean)')
    ax.set_title('Comparison of Principal Component (PC1 v.s. PC2)')
    ax.set_xticks(x)
    ax.set_xticklabels(name_list)
    ax.legend()
    ax.grid(axis='y', linestyle='--', alpha=0.7)
    
    plt.tight_layout()
    plt.show()